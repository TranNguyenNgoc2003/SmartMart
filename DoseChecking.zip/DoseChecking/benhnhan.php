<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Bệnh Nhân</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="benhnhan.css">
</head>
<body>
    <div class="form">
        <div class="row">
            <div class="col">
                <h2>Quản lý Bệnh Nhân</h2>
                <form action="./process_benhnhan.php" method="post">
                    <div class="container">

                        </div>
                        <!-- Mã ID bệnh nhân -->
                        <div class="mb-3 row">
                            <label for="id" class="col-3 col-form-label">Nhập mã ID:</label>
                            <div class="col-9">
                                <input type="text" class="form-control" name="id" id="id" placeholder="Nhập mã ID">
                            </div>
                        </div>

                        <!-- Họ tên -->
                        <div class="mb-3 row">
                            <label for="txtHoTen" class="col-3 col-form-label">Họ & Tên:</label>
                            <div class="col-9">
                                <input type="text" class="form-control" name="txtHoTen" id="txtHoTen" placeholder="Nhập họ tên">
                            </div>
                        </div>
                        <!-- SDT -->
                        <div class="mb-3 row">
                            <label for="txtSDT" class="col-3 col-form-label">Số điện thoại:</label>
                            <div class="col-9">
                                <input type="text" class="form-control" name="txtSDT" id="txtSDT" placeholder="Nhập Số điện thoại">
                            </div>
                        </div>
                       
                       
                        <!-- Địa chỉ -->
                        <div class="mb-3 row">
                            <label for="txtDiaChi" class="col-3 col-form-label">Địa chỉ:</label>
                            <div class="col-9">
                                <input type="text" class="form-control" name="txtDiaChi" id="txtDiaChi" placeholder="Nhập địa chỉ">
                            </div>
                        </div>


                         <!-- Thuốc dị ứng-->
                         <div class="mb-3 row">
                            <label for="txtThuocDiUng" class="col-3 col-form-label">Thuốc Dị Ứng:</label>
                            <div class="col-9">
                                <input type="text" class="form-control" name="txtThuocDiUng" id="txtThuocDiUng" placeholder="Thuốc Dị ứng">
                            </div>
                        </div>


                        <!-- Submit_reset-->
                        <div class="row" style="width: 60%; margin: 0 auto;">
                            <button style="margin-bottom: 10px;" type="submit" class="btn btn-primary">Submit</button>
                            <button type="reset" class="btn btn-primary">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
