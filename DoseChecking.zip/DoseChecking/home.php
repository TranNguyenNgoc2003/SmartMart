<?php
// Kết nối đến cơ sở dữ liệu (thay đổi thông tin kết nối theo cấu hình của bạn)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dosechecking";

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
}
$text="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ho_ten = $_POST["txtHoTen"];
    $sdt = $_POST["txtSDT"];
    $dia_chi = $_POST["txtDiaChi"];
    $thuoc_di_ung = $_POST["txtThuocDiUng"];
    
    // Chuẩn bị câu truy vấn SQL để chèn dữ liệu vào bảng BENH_NHAN
    $sql = "INSERT INTO BENH_NHAN (HO_TEN, SDT, DIA_CHI, THUOC_DI_UNG) 
            VALUES ('$ho_ten', '$sdt', '$dia_chi', '$thuoc_di_ung')";

    if ($conn->query($sql) === TRUE) {
        $text = "Thêm Bệnh Nhân thành công.";
    } else {
        $text = "Lỗi: " . $sql . "<br>" . $conn->error;
    }
}

// Đóng kết nối
$conn->close();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dosechecking</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap.min.css" integrity="sha512-Ez0cGzNzHR1tYAv56860NLspgUGuQw16GiOOp/I2LuTmpSK9xDXlgJz3XN4cnpXWDmkNBKXR/VDMTCnAaEooxA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/js/bootstrap.bundle.min.js" integrity="sha512-sH8JPhKJUeA9PWk3eOcOl8U+lfZTgtBXD41q6cO/slwxGHCxKcW45K4oPCUhHG7NMB4mbKEddVmPuTXtpbCbFA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="./css/home.css">
</head>
<body>
    <div class="container-fluid" >
        <nav
            class="navbar navbar-expand-sm navbar-dark"
            style=" margin:0px -12px;"
        >
            <a class="navbar-brand" href="#" style="font-weight: bold;">Dosechecking</a>
            <button
                class="navbar-toggler d-lg-none"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapsibleNavId"
                aria-controls="collapsibleNavId"
                aria-expanded="false"
                aria-label="Toggle navigation"
            ></button>
            <div class="collapse navbar-collapse" id="collapsibleNavId" style="display: flex; justify-content: end;">
                <form class="d-flex my-2 my-lg-0" style="margin-right: 20px; justify-content: end;">
                    <input
                        class="form-control me-sm-2"
                        type="text"
                        placeholder="Search"
                    />
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                        Search
                    </button>
                </form>
            </div>
        </nav>
        
    </div>

    <div class="menu">
        <!-- Nav tabs -->
        <ul
            class="nav nav-tabs"
            id="navId"
            role="tablist"
        >
            <li class="nav-item">
                <a
                    href="#tab1Id"
                    class="nav-link active"
                    data-bs-toggle="tab"
                    aria-current="page"
                    style="color: grey;"
                    >Bệnh nhân</a
                >
            </li>
            <li class="nav-item dropdown">
                <a
                    class="nav-link dropdown-toggle"
                    data-bs-toggle="dropdown"
                    href="#"
                    role="button"
                    aria-haspopup="true"
                    aria-expanded="false"
                    style="color: grey;"
                    >Khám bệnh</a
                >
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="./donthuoc.php" style="color: grey;">Đơn thuốc</a>
                    <a class="dropdown-item" href="./loaithuoc.php" style="color: grey;">Thuốc mới</a>
                    <a class="dropdown-item" href="./loaibenh.php" style="color: grey;">Loại bệnh</a>
                </div>
            </li>
            
            <li class="nav-item" role="presentation">
                <a href="./hosokhambenh.php" class="nav-link" style="color: grey;">Hồ sơ khám bệnh</a
                >
            </li> 
        </ul>
        
        <!-- Tab panes -->
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="tab1Id" role="tabpanel">
                <div class="form">
                    <div class="row">
                        <div class="col">
                            <h2>Thêm Bệnh Nhân Mới</h2>
                            <form action="<?php htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                                <div class="container">

                                    </div>
                                    <!-- Họ tên -->
                                    <div class="mb-3 row">
                                        <label for="txtHoTen" class="col-3 col-form-label">Họ & Tên:</label>
                                        <div class="col-9">
                                            <input type="text" class="form-control" name="txtHoTen" id="txtHoTen" placeholder="Nhập họ tên">
                                        </div>
                                    </div>
                                    <!-- SDT -->
                                    <div class="mb-3 row">
                                        <label for="txtSDT" class="col-3 col-form-label">Số điện thoại:</label>
                                        <div class="col-9">
                                            <input type="text" class="form-control" name="txtSDT" id="txtSDT" placeholder="Nhập Số điện thoại">
                                        </div>
                                    </div>
                                
                                
                                    <!-- Địa chỉ -->
                                    <div class="mb-3 row">
                                        <label for="txtDiaChi" class="col-3 col-form-label">Địa chỉ:</label>
                                        <div class="col-9">
                                            <input type="text" class="form-control" name="txtDiaChi" id="txtDiaChi" placeholder="Nhập địa chỉ">
                                        </div>
                                    </div>


                                    <!-- Thuốc dị ứng-->
                                    <div class="mb-3 row">
                                        <label for="txtThuocDiUng" class="col-3 col-form-label">Thuốc Dị Ứng:</label>
                                        <div class="col-9">
                                            <input type="text" class="form-control" name="txtThuocDiUng" id="txtThuocDiUng" placeholder="Thuốc Dị ứng">
                                        </div>
                                    </div>

                                    <span style="color: red;"><?php echo $text; ?></span>
                                    <!-- Submit_reset-->
                                    <div class="row" style="width: 60%; margin: 0 auto;">
                                        <button style="margin-bottom: 10px;" type="submit" class="btn btn-primary">Thêm mới</button>
                                        <button type="reset" class="btn btn-primary">Làm mới</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- (Optional) - Place this js code after initializing bootstrap.min.js or bootstrap.bundle.min.js -->
        <script>
            var triggerEl = document.querySelector("#navId a");
            bootstrap.Tab.getInstance(triggerEl).show(); // Select tab by name
        </script>
        
    </div>
    
</body>
</html>