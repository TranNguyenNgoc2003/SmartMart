﻿CREATE DATABASE dosechecking;
USE dosechecking;
-- Tạo bảng bác sĩ
CREATE TABLE BAC_SI(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	HO_TEN VARCHAR(255) NOT NULL,
	EMAIL VARCHAR(255) NOT NULL,
	Password_BS VARCHAR(255) NOT NULL,
	SDT VARCHAR(15) NOT NULL,
	CHUC_VU VARCHAR(50) NOT NULL,
	KHOA VARCHAR(50) NOT NULL
);

-- Tạo bảng bệnh nhân
CREATE TABLE BENH_NHAN(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	HO_TEN VARCHAR(255) NOT NULL,
	SDT VARCHAR(15) NOT NULL,
	DIA_CHI VARCHAR(255) NOT NULL,
	THUOC_DI_UNG VARCHAR(255)
);

CREATE TABLE LOAI_THUOC(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	TEN_THUOC VARCHAR(255) NOT NULL,
	MAX_LIEULUONG INT NOT NULL,
	MIN_LIEULUONG INT NOT NULL,
	MAX_TANSUAT INT NOT NULL,
	MIN_TANSUAT INT NOT NULL,
	KHOILUONG_VIEN INT NOT NULL,
	GHICHU VARCHAR(255)
);

CREATE TABLE LOAI_BENH(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	TEN_BENH VARCHAR(255) NOT NULL,
	GHICHU VARCHAR(255)
);

CREATE TABLE DON_THUOC(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	ID_LOAIBENH INT NOT NULL,
	FOREIGN KEY (ID_LOAIBENH) REFERENCES LOAI_BENH(ID),
	ID_LOAITHUOC INT NOT NULL,
	FOREIGN KEY (ID_LOAITHUOC) REFERENCES LOAI_THUOC(ID),
	GHICHU VARCHAR(255)
);

CREATE TABLE HO_SO_KHAM_BENH(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	ID_BENHNHAN INT NOT NULL,
	FOREIGN KEY (ID_BENHNHAN) REFERENCES BENH_NHAN(ID),
	ID_BACSI INT NOT NULL,
	FOREIGN KEY (ID_BACSI) REFERENCES BAC_SI(ID),
	ID_LOAI_BENH INT NOT NULL,
	FOREIGN KEY (ID_LOAI_BENH) REFERENCES LOAI_BENH(ID)
);

INSERT INTO BAC_SI (HO_TEN, EMAIL, Password_BS, SDT, CHUC_VU, KHOA)
VALUES 
  ('Nguyễn Văn A', 'nguyenvana@email.com', 'passwordA', '123456789', 'Chuyên gia 1', 'Khoa A'),
  ('Trần Thị B', 'tranthib@email.com', 'passwordB', '987654321', 'Chuyên gia 2', 'Khoa B');

-- Chèn dữ liệu cho bảng BENH_NHAN
INSERT INTO BENH_NHAN (HO_TEN, SDT, DIA_CHI, THUOC_DI_UNG)
VALUES 
  ('Nguyễn Thị C', '111111111', '123 Đường X, Quận Y', 'Thuốc A, Thuốc B'),
  ('Lê Văn D', '222222222', '456 Đường Z, Quận W', 'Thuốc C, Thuốc D');
-- Chèn dữ liệu cho bảng LOAI_THUOC
INSERT INTO LOAI_THUOC (TEN_THUOC, MAX_LIEULUONG, MIN_LIEULUONG, MAX_TANSUAT, MIN_TANSUAT, KHOILUONG_VIEN, GHICHU)
VALUES 
  ('Paracetamol', 2, 1, 4, 1, 50, 'Dùng cho cảm lạnh và đau đầu'),
  ('Ibuprofen', 3, 1, 3, 1, 40, 'Dùng cho viêm nhiễm và đau nhức cơ'),
  ('Amoxicillin', 1, 1, 2, 1, 30, 'Kháng sinh cho các bệnh nhiễm trùng');

-- Chèn dữ liệu cho bảng LOAI_BENH
INSERT INTO LOAI_BENH (TEN_BENH, GHICHU)
VALUES 
  ('Cảm lạnh', 'Bệnh thông thường gây cảm giác không thoải mái'),
  ('Viêm họng', 'Viêm nhiễm ở họng gây khó chịu và đau rát'),
  ('Viêm xoang', 'Nhiễm trùng ở xoang mũi gây đau đầu và áp lực');

-- Chèn dữ liệu cho bảng DON_THUOC
INSERT INTO DON_THUOC (ID_LOAIBENH, ID_LOAITHUOC, GHICHU)
VALUES 
  (1, 1, 'Điều trị cảm lạnh với Paracetamol'),
  (2, 2, 'Giảm viêm nhiễm họng với Ibuprofen'),
  (3, 3, 'Kháng sinh Amoxicillin cho nhiễm trùng');
	
	-- Chèn dữ liệu cho bảng HO_SO_KHAM_BENH
-- Chèn dữ liệu cho bảng HO_SO_KHAM_BENH
INSERT INTO HO_SO_KHAM_BENH (ID_BENHNHAN, ID_BACSI, ID_LOAI_BENH)
VALUES 
  (1, 1, 1),
  (2, 2, 2),
  (1, 2, 1),
  (2, 1, 3);

-- Lưu ý: 1 và 2 là ID của bệnh nhân, 1 và 2 là ID của bác sĩ, 1, 2 và 3 là ID của loại bệnh.
-- Các giá trị phải tương ứng với các ID đã tồn tại trong bảng BENH_NHAN, BAC_SI và LOAI_BENH.
