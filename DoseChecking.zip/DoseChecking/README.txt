Thành viên nhóm 6:
	Trần Nguyên Ngọc 21CNTT2 (Nhóm trưởng)
		Phần trăm đóng góp: 33,33%

	Nguyễn Đình Minh Thành 21CNTT3
		Phần trăm đóng góp: 33,33%

	Nguyễn An Kiệt 21CNTT2
		Phần trăm đóng góp: 33,33%

-----------------------------------------------------------------------------------------------------
- sau khi tải code và giải nén code
- copy code vào folder "htdocs" thường được lưu ở đường dẫn này "C:\xampp\htdocs"

- mở XAMPP Control Panel-> bật "Apache" và "MySQL"

- mở file "DoseChecking.sql" ở trong flie code vừa tải -> copy code sql.
- mở trình duyệt và tìm kiếm "http://localhost:80/phpmyadminn"
- chọn mục "SQL" -> paste code sql vừa copy và chạy code.

- mở trình duyệt và tìm kiếm "http://localhost:80/dosechecking" để truy cập website

(Lưu ý:
	Chú ý cổng port của máy chủ xampp ở máy của bạn.
	
	Ví dụ: trong phần "port" của "Apache" trong máy chủ "Xampp" bạn vừa mở có cổng là: "443, 80" thì đường dẫn sẽ là "http://localhost:80/phpmyadminn" và "http://localhost:80/dosechecking".
)
----------------------------------------------------------------------------------------------------
- sau khi truy cập được vào website
- chọn "Sign Up" để tạo tài khoản bác sĩ.
- sau khi tạo hãy đăng nhập vào website bằng tài khoản đó.

- ở trang "bệnh nhân" bạn hãy nhập thông tin bệnh nhân để thêm bệnh nhân mới.

- chuyển qua mục "Khám bệnh" 
	+ chọn "đơn thuốc" để thêm đơn thuốc mới dựa trên loại bệnh
	+ chọn "Thuốc mới" để thêm các loại thuốc mới	
	+ chọn "Loại bệnh" để thêm Loại bệnh mới

- chuyển qua mục "Hồ sơ khám bệnh" lựa chọn tên "bệnh nhân" và "bác sĩ" cấp thuốc và chọn "loại bệnh" để cấp thuốc cho bệnh nhân.
