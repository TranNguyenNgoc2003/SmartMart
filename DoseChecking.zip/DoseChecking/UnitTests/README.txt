- Mở chương trình bằng phần mềm Visual Studio sau đó chạy chương trình bằng đoạn mã sau nhập trên Terminal: 
python medication.py 

- giải thích về đoạn mã: 
- Class MedicationDosageChecker:
init method:

Phương thức khởi tạo (constructor) của class, nhận các tham số là thông tin về thuốc như tên thuốc (ten_thuoc), 
tên bệnh nhân (ten_benh_nhan), liều dùng trong ngày (lieu_dung_ngay), liều dùng trong đêm (lieu_dung_dem), 
và khối lượng toàn bộ (khoi_luong_toan_bo).
kiem_tra_lieu_dung_thuoc method:

Phương thức này kiểm tra xem liệu lượng thuốc có nằm trong phạm vi chấp nhận không.
Nếu liều dùng trong ngày hoặc liều dùng trong đêm là số âm, trả về thông báo "Lieu dung khong hop le".
Nếu tổng liều dùng (ngày và đêm) vượt quá 10, trả về thông báo "Tong lieu dung qua cao".
Nếu khối lượng toàn bộ là 0 hoặc âm, trả về thông báo "Khoi luong toan bo khong hop le".
Nếu không có điều kiện nào thỏa mãn, trả về "Lieu dung nam trong khoang chấp nhận duoc".
- Class TestMedicationDosageChecker:
+ test_lieu_dung_hop_le method:
 Phương thức kiểm thử xem hàm kiem_tra_lieu_dung_thuoc trả về kết quả đúng ("Lieu dung nam trong khoang chấp nhận duoc") khi liều dùng là hợp lệ.
+ test_lieu_dung_khong_hop_le method:
Phương thức kiểm thử xem hàm kiem_tra_lieu_dung_thuoc trả về kết quả đúng ("Lieu dung khong hop le") khi liều dùng là không hợp lệ (âm).
+ test_tong_lieu_dung_qua_cao method:
Phương thức kiểm thử xem hàm kiem_tra_lieu_dung_thuoc trả về kết quả đúng ("Tong lieu dung qua cao") khi tổng liều dùng vượt quá 10.
+ test_khoi_luong_toan_bo_khong_hop_le method:
Phương thức kiểm thử xem hàm kiem_tra_lieu_dung_thuoc trả về kết quả đúng ("Khoi luong toan bo khong hop le") khi khối lượng toàn bộ là 0 hoặc âm.