import unittest

class MedicationDosageChecker:
    def __init__(self, ten_thuoc, ten_benh_nhan, lieu_dung_ngay, lieu_dung_dem, khoi_luong_toan_bo):
        self.ten_thuoc = ten_thuoc
        self.ten_benh_nhan = ten_benh_nhan
        self.lieu_dung_ngay = lieu_dung_ngay
        self.lieu_dung_dem = lieu_dung_dem
        self.khoi_luong_toan_bo = khoi_luong_toan_bo

    def kiem_tra_lieu_dung_thuoc(self):
        if self.lieu_dung_ngay < 0 or self.lieu_dung_dem < 0:
            return "Lieu dung khong hop le"
        tong_lieu_dung = self.lieu_dung_ngay + self.lieu_dung_dem
        if tong_lieu_dung > 10:
            return "Tong lieu dung qua cao"
        if self.khoi_luong_toan_bo <= 0:
            return "Khoi luong toan bo khong hop le"
        return "Lieu dung nam trong khoang chấp nhận duoc"

class TestMedicationDosageChecker(unittest.TestCase):
    def test_lieu_dung_hop_le(self):
        checker = MedicationDosageChecker("Aspirin", "John Doe", 3, 2, 150)
        result = checker.kiem_tra_lieu_dung_thuoc()
        self.assertEqual(result, "Lieu dung nam trong khoang chấp nhận duoc")

    def test_lieu_dung_khong_hop_le(self):
        checker = MedicationDosageChecker("Ibuprofen", "Jane Doe", -1, 4, 200)
        result = checker.kiem_tra_lieu_dung_thuoc()
        self.assertEqual(result, "Lieu dung khong hop le")

    def test_tong_lieu_dung_qua_cao(self):
        checker = MedicationDosageChecker("Paracetamol", "Bob Smith", 8, 4, 180)
        result = checker.kiem_tra_lieu_dung_thuoc()
        self.assertEqual(result, "Tong lieu dung qua cao")

    def test_khoi_luong_toan_bo_khong_hop_le(self):
        checker = MedicationDosageChecker("Antibiotic", "Alice Johnson", 2, 1, 0)
        result = checker.kiem_tra_lieu_dung_thuoc()
        self.assertEqual(result, "Khoi luong toan bo khong hop le")

if __name__ == '__main__':
    unittest.main()
