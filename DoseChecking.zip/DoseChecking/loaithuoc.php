<?php
// Kết nối đến cơ sở dữ liệu (thay đổi thông tin kết nối theo cấu hình của bạn)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dosechecking";

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
}
$text="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ten_thuoc = $_POST["ten_thuoc"];
    $max_lieuluong = $_POST["max_lieuluong"];
    $min_lieuluong = $_POST["min_lieuluong"];
    $max_tansuat = $_POST["max_tansuat"];
    $min_tansuat = $_POST["min_tansuat"];
    $khoiluong_vien = $_POST["khoiluong_vien"];
    $ghichu = $_POST["ghichu"];

    // Chuẩn bị câu truy vấn SQL để chèn dữ liệu vào bảng LOAI_THUOC
    $sql = "INSERT INTO LOAI_THUOC (TEN_THUOC, MAX_LIEULUONG, MIN_LIEULUONG, MAX_TANSUAT, MIN_TANSUAT, KHOILUONG_VIEN, GHICHU) 
            VALUES ('$ten_thuoc', '$max_lieuluong', '$min_lieuluong', '$max_tansuat', '$min_tansuat', '$khoiluong_vien', '$ghichu')";

if ($conn->query($sql) === TRUE) {
    $text = "Thêm thuốc mới thành công.";
} else {
    $text = "Lỗi: " . $sql . "<br>" . $conn->error;
}
} 

// Đóng kết nối
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dosechecking</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap.min.css" integrity="sha512-Ez0cGzNzHR1tYAv56860NLspgUGuQw16GiOOp/I2LuTmpSK9xDXlgJz3XN4cnpXWDmkNBKXR/VDMTCnAaEooxA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/js/bootstrap.bundle.min.js" integrity="sha512-sH8JPhKJUeA9PWk3eOcOl8U+lfZTgtBXD41q6cO/slwxGHCxKcW45K4oPCUhHG7NMB4mbKEddVmPuTXtpbCbFA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="./css/home.css">
</head>
<body>
    <div class="container-fluid" >
        <nav
            class="navbar navbar-expand-sm navbar-dark"
            style=" margin:0px -12px;"
        >
            <a class="navbar-brand" href="#" style="font-weight: bold;">Dosechecking</a>
            <button
                class="navbar-toggler d-lg-none"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapsibleNavId"
                aria-controls="collapsibleNavId"
                aria-expanded="false"
                aria-label="Toggle navigation"
            ></button>
            <div class="collapse navbar-collapse" id="collapsibleNavId" style="display: flex; justify-content: end;">
                <form class="d-flex my-2 my-lg-0" style="margin-right: 20px; justify-content: end;">
                    <input
                        class="form-control me-sm-2"
                        type="text"
                        placeholder="Search"
                    />
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                        Search
                    </button>
                </form>
            </div>
        </nav>
        
    </div>

    <div class="menu">
        <!-- Nav tabs -->
        <ul
            class="nav nav-tabs"
            id="navId"
            role="tablist"
        >
            <li class="nav-item">
                <a
                    href="./home.php"
                    class="nav-link"
                    aria-current="page"
                    style="color: grey;"
                    >Bệnh nhân</a
                >
            </li>
            <li class="nav-item dropdown">
                <a
                    class="nav-link dropdown-toggle active"
                    data-bs-toggle="dropdown"
                    href="#"
                    role="button"
                    aria-haspopup="true"
                    aria-expanded="false"
                    style="color: grey;"
                    >Khám bệnh</a
                >
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="./donthuoc.php" style="color: grey;">Đơn thuốc</a>
                    <a class="dropdown-item" href="#tab3Id" style="color: grey;">Thuốc mới</a>
                    <a class="dropdown-item" href="./loaibenh.php" style="color: grey;">Loại bệnh</a>

                </div>
            </li>
            
            <li class="nav-item" role="presentation">
            <a href="./hosokhambenh.php" class="nav-link" style="color: grey;">Hồ sơ khám bệnh</a
                >
            </li> 
        </ul>
        
        <!-- Tab panes -->
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="tab3Id" role="tabpanel">
            <div class="form">
                    <div class="row">
                        <div class="col">
                            <h2>Quản lý Loại Thuốc</h2>
                            <form action="<?php htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                                <div class="container">

                                    

                                    <!-- Tên Thuốc -->
                                    <div class="mb-3 row">
                                        <label for="ten_thuoc" class="col-3 col-form-label">Tên Thuốc:</label>
                                        <div class="col-9">
                                            <input type="text" class="form-control" name="ten_thuoc" id="ten_thuoc" placeholder="Nhập tên thuốc" required>
                                        </div>
                                    </div>

                                    <!-- Max Lieu Luong -->
                                    <div class="mb-3 row">
                                        <label for="max_lieuluong" class="col-3 col-form-label">Max Liều Lượng:</label>
                                        <div class="col-9">
                                            <input type="number" class="form-control" name="max_lieuluong" id="max_lieuluong" placeholder="Nhập max liều lượng" required>
                                        </div>
                                    </div>

                                    <!-- Min Lieu Luong -->
                                    <div class="mb-3 row">
                                        <label for="min_lieuluong" class="col-3 col-form-label">Min Liều Lượng:</label>
                                        <div class="col-9">
                                            <input type="number" class="form-control" name="min_lieuluong" id="min_lieuluong" placeholder="Nhập min liều lượng" required>
                                        </div>
                                    </div>

                                    <!-- Max Tan Suat -->
                                    <div class="mb-3 row">
                                        <label for="max_tansuat" class="col-3 col-form-label">Max Tần Suất:</label>
                                        <div class="col-9">
                                            <input type="number" class="form-control" name="max_tansuat" id="max_tansuat" placeholder="Nhập max tần suất" required>
                                        </div>
                                    </div>

                                    <!-- Min Tan Suat -->
                                    <div class="mb-3 row">
                                        <label for="min_tansuat" class="col-3 col-form-label">Min Tần Suất:</label>
                                        <div class="col-9">
                                            <input type="number" class="form-control" name="min_tansuat" id="min_tansuat" placeholder="Nhập min tần suất" required>
                                        </div>
                                    </div>

                                    <!-- Khoi Luong Vien -->
                                    <div class="mb-3 row">
                                        <label for="khoiluong_vien" class="col-3 col-form-label">Khối Lượng Viên:</label>
                                        <div class="col-9">
                                            <input type="number" class="form-control" name="khoiluong_vien" id="khoiluong_vien" placeholder="Nhập khối lượng viên" required>
                                        </div>
                                    </div>

                                    <!-- Ghi Chu -->
                                    <div class="mb-3 row">
                                        <label for="ghichu" class="col-3 col-form-label">Ghi Chú:</label>
                                        <div class="col-9">
                                            <textarea class="form-control" name="ghichu" id="ghichu" placeholder="Nhập ghi chú"></textarea>
                                        </div>
                                    </div>
                                    <span style="color: red;"><?php echo $text; ?></span>
                                    <!-- Submit_reset-->
                                    <div class="row" style="width: 60%; margin: 0 auto;">
                                        <button style="margin-bottom: 10px;"  type="submit" class="btn btn-primary">Xác nhận</button>
                                        <button type="reset" class="btn btn-primary">Làm mới</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        
        <!-- (Optional) - Place this js code after initializing bootstrap.min.js or bootstrap.bundle.min.js -->
        <script>
            var triggerEl = document.querySelector("#navId a");
            bootstrap.Tab.getInstance(triggerEl).show(); // Select tab by name
        </script>
        
    </div>
    
</body>
</html>